import android.support.v4.app.Fragment

class CrimeFragment : Fragment() {
}